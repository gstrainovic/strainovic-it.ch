<?php
declare(strict_types=1);

namespace StrainovicIT\Rappenrundung;

final class Plugin
{
    public const VERSION = '0.3.1';
    public const OPTION = 'rappenrundung_bezeichnung';

    /** Standardwerte früherer Versionen; stehen sie in der Datenbank, gilt der übersetzte Standard. */
    private const ALTE_STANDARDS = ['Rundungsdifferenz'];

    /** @param string $datei Basisname der Plugin-Datei (plugin_basename), für die Links in der eigenen Plugin-Zeile */
    public static function starten(string $datei = ''): void
    {
        if (!class_exists('WooCommerce')) {
            return;
        }
        add_action('init', [self::class, 'textdomainLaden'], 0);
        (new Warenkorb('get_woocommerce_currency', [self::class, 'bezeichnung']))->registrieren();
        add_filter('woocommerce_general_settings', [self::class, 'einstellungen']);
        add_filter('plugin_row_meta', static fn (array $links, string $plugin): array => Connectoren::zeilenLinks($links, $plugin, $datei), 10, 2);
    }

    /** Lädt die mitgelieferte Übersetzung zur Seitensprache (de_CH_informal → de_CH, fr_BE → fr_FR usw.). */
    public static function textdomainLaden(): void
    {
        $locale = determine_locale();
        $datei = Sprache::datei($locale);
        if ($datei !== null) {
            load_textdomain('rappenrundung', dirname(__DIR__) . '/languages/rappenrundung-' . $datei . '.mo', $locale);
        }
    }

    public static function bezeichnung(): string
    {
        $wert = trim((string) get_option(self::OPTION, ''));

        return $wert !== '' && !in_array($wert, self::ALTE_STANDARDS, true) ? $wert : self::standard();
    }

    private static function standard(): string
    {
        return __('Rounding to 5 cents', 'rappenrundung');
    }

    /**
     * Feld für die Bezeichnung der Rundungsposition, unter «Allgemein → Währungsoptionen».
     * Leer = übersetzter Standard; er steht nur als Platzhalter im Feld, damit Speichern ihn nicht in einer Sprache festhält.
     *
     * @param list<array<string, mixed>> $felder
     * @return list<array<string, mixed>>
     */
    public static function einstellungen(array $felder): array
    {
        $neu = [
            'id' => self::OPTION,
            'type' => 'text',
            'title' => __('Rounding line', 'rappenrundung'),
            'desc' => esc_html__('Label of the rounding line in the cart and in the order. Leave empty to use the default in the language of the site. Only applies when the shop currency is CHF.', 'rappenrundung')
                . '<br>' . Connectoren::hinweis(),
            'default' => '',
            'placeholder' => self::standard(),
            'desc_tip' => false,
        ];
        $ergebnis = [];
        $eingefuegt = false;
        foreach ($felder as $feld) {
            if (!$eingefuegt && ($feld['id'] ?? '') === 'pricing_options' && ($feld['type'] ?? '') === 'sectionend') {
                $ergebnis[] = $neu;
                $eingefuegt = true;
            }
            $ergebnis[] = $feld;
        }
        if (!$eingefuegt) {
            $ergebnis[] = $neu;
        }

        return $ergebnis;
    }
}
