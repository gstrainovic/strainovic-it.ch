<?php
declare(strict_types=1);

namespace StrainovicIT\Rappenrundung;

/** Bildet die Sprache der Seite auf die mitgelieferte Übersetzung ab (languages/strainovic-it-rappenrundung-<datei>.mo). */
final class Sprache
{
    /** @return string|null null = keine Datei, die englischen Quelltexte gelten */
    public static function datei(string $locale): ?string
    {
        if ($locale === 'de_CH' || str_starts_with($locale, 'de_CH_')) {
            return 'de_CH';
        }

        return match (explode('_', $locale)[0]) {
            'de' => 'de_DE',
            'fr' => 'fr_FR',
            'it' => 'it_IT',
            default => null,
        };
    }
}
